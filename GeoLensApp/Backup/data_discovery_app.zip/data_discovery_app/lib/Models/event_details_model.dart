import 'package:data_discovery_for_earth/Models/event_info_model.dart';

class EventDetailsModel{
  EventInfoModel event ;
  String lang;

  EventDetailsModel({this.event,this.lang});
}