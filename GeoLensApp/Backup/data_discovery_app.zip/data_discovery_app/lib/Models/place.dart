class Place{

  String name ;
  String aver ;
  String id;
  Place(this.name,this.aver ,this.id);
}