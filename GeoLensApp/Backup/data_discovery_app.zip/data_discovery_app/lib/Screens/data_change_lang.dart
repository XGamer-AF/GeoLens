class Data{
  int sec ;
  int sec2;
  String screen ;
  String lang ;
  Data({this.screen,this.sec,this.lang,this.sec2});
}
