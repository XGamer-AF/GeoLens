import 'package:flutter/material.dart';

class Events_New extends StatefulWidget {
  @override
  _Events_NewState createState() => _Events_NewState();
}

class _Events_NewState extends State<Events_New> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tested'),
      ),
    );
  }
}
