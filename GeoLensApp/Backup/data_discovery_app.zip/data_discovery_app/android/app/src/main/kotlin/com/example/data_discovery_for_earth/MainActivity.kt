package com.example.data_discovery_for_earth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
